from rest_framework import serializers

from .models import ShopItem


class ShopItemSerializer(serializers.ModelSerializer):
    seed_key = serializers.SerializerMethodField()  # 씨앗이면 어떤 종인지 (종 정보는 /api/garden/species/)

    class Meta:
        model = ShopItem
        fields = ('id', 'item_type', 'name', 'emoji', 'description', 'price', 'seed_key')

    def get_seed_key(self, obj):
        return obj.seed_type.key if obj.seed_type_id else None
