from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from . import sim
from .models import GardenPlot, SeedType, UserSeedInventory
from .serializers import GardenPlotSerializer, SeedTypeSerializer, UserSeedInventorySerializer


def garden_state(user, detail=''):
    """정원 전체 상태(탄소 농도 + 9칸 화분 + 보유 아이템). 모든 정원 API가 이 모양으로 응답해요."""
    plots = list(GardenPlot.objects.filter(user=user).select_related('seed_type'))
    poll = sim.pollination_bonus(plots)
    ctx = {'sun': sim.sun_levels(plots), 'poll': poll}
    return {
        'detail': detail,
        'co2_ppm': round(user.co2_ppm, 1),
        'co2_baseline': sim.CO2_BASELINE,
        'co2_limit': sim.CO2_LIMIT,
        'step_minutes': sim.step_minutes(),
        'nutrients': user.nutrients,
        'microbes': user.microbes,
        'diversity': sim.diversity(plots),               # 살아있는 식물 종류 수
        'pollination': round((poll - 1) * 100),          # 꽃가루받이 성장 보너스(%)
        'plots': GardenPlotSerializer(plots, many=True, context=ctx).data,
    }


def _bad(msg):
    return Response({'detail': msg}, status=status.HTTP_400_BAD_REQUEST)


def _living_plot(user, slot_index):
    """살아있는 나무가 심어진 화분을 돌려줘요. 아니면 (None, 에러 응답)."""
    sim.advance(user)
    plot = GardenPlot.objects.filter(user=user, slot_index=slot_index).first()
    if plot is None or plot.seed_type_id is None:
        return None, _bad('심어진 식물이 없어요.')
    if plot.is_dead:
        return None, _bad('시든 나무예요. 뽑아서 정리해 주세요.')
    return plot, None


class GardenListView(APIView):
    """내 정원 상태 조회. 조회할 때마다 지난 시간만큼 정원이 자동으로 계산돼요."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        sim.advance(request.user)
        return Response(garden_state(request.user))


class SpeciesListView(generics.ListAPIView):
    """모든 씨앗(나무·꽃) 종류. 로그인하지 않아도 볼 수 있어요 (상점 구경용)."""
    queryset = SeedType.objects.all().order_by('kind', 'difficulty', 'id')
    serializer_class = SeedTypeSerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = None


class SeedInventoryView(APIView):
    """보유 씨앗 목록."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        qs = UserSeedInventory.objects.filter(user=request.user, quantity__gt=0)
        return Response(UserSeedInventorySerializer(qs, many=True).data)


class PlantSeedView(APIView):
    """빈 화분에 씨앗 심기."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_index):
        sim.advance(request.user)
        plot = GardenPlot.objects.filter(user=request.user, slot_index=slot_index).first()
        if plot is None or not plot.is_empty:
            return _bad('빈 화분이 아니에요.')

        inv = UserSeedInventory.objects.filter(
            user=request.user, seed_type__key=request.data.get('seed_key'), quantity__gt=0,
        ).first()
        if inv is None:
            return _bad('보유한 씨앗이 없어요.')

        inv.quantity -= 1
        inv.save(update_fields=['quantity'])
        plot.seed_type = inv.seed_type
        plot.growth_stage = 0
        plot.growth_progress = 0
        plot.stress = 0
        plot.stress_reason = ''
        plot.death_reason = ''
        plot.save()
        return Response(garden_state(request.user, f'{inv.seed_type.name} 씨앗을 심었어요'))


class WaterPlotView(APIView):
    """물 주기 (무료)."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_index):
        plot, err = _living_plot(request.user, slot_index)
        if err:
            return err
        if plot.water >= 100:
            return _bad('물이 이미 가득해요.')
        plot.water = min(100.0, plot.water + sim.WATER_AMOUNT)
        plot.save(update_fields=['water'])
        return Response(garden_state(request.user, '💧 물을 줬어요'))


class FeedPlotView(APIView):
    """영양제 주기: 흙의 영양분을 채워요."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_index):
        plot, err = _living_plot(request.user, slot_index)
        if err:
            return err
        user = request.user
        if user.nutrients < 1:
            return _bad('영양제가 없어요.')
        if plot.nutrients >= 100:
            return _bad('영양분이 이미 가득해요.')
        user.nutrients -= 1
        user.save(update_fields=['nutrients'])
        plot.nutrients = min(100.0, plot.nutrients + sim.FEED_AMOUNT)
        plot.save(update_fields=['nutrients'])
        return Response(garden_state(user, '🧪 영양분을 채웠어요'))


class MicrobePlotView(APIView):
    """미생물제 주기: 흙 속 미생물이 늘어나 나무가 빨리 자라고 영양분도 만들어져요."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_index):
        plot, err = _living_plot(request.user, slot_index)
        if err:
            return err
        user = request.user
        if user.microbes < 1:
            return _bad('미생물제가 없어요.')
        if plot.microbes >= 100:
            return _bad('미생물이 이미 가득해요.')
        user.microbes -= 1
        user.save(update_fields=['microbes'])
        plot.microbes = min(100.0, plot.microbes + sim.MICROBE_AMOUNT)
        plot.save(update_fields=['microbes'])
        return Response(garden_state(user, '🦠 미생물이 늘어났어요'))


class DigPlotView(APIView):
    """화분을 비움(뽑기). 식물만 사라지고 흙 상태는 그대로예요."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_index):
        sim.advance(request.user)
        plot = GardenPlot.objects.filter(user=request.user, slot_index=slot_index).first()
        if plot is None:
            return Response({'detail': '화분이 없어요.'}, status=status.HTTP_404_NOT_FOUND)
        plot.reset_plant()
        plot.save()
        return Response(garden_state(request.user, '화분을 비웠어요'))


class PlantPhotoView(APIView):
    """사진을 찍어 화분에 심기 → 서버에서 픽셀 아트로 변환 (장식용이라 시뮬레이션은 적용 안 돼요)."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_index):
        photo = request.data.get('photo')
        if photo is None:
            return _bad('사진이 필요해요.')

        sim.advance(request.user)
        plot = GardenPlot.objects.filter(user=request.user, slot_index=slot_index).first()
        if plot is None or not plot.is_empty:
            return _bad('빈 화분이 아니에요.')

        plot.photo = photo
        plot.growth_stage = 4
        plot.save()
        plot.make_pixel_art()
        plot.save(update_fields=['pixel_photo'])
        return Response(garden_state(request.user, '🖼️ 픽셀 사진을 심었어요'))
