import math

from django.utils import timezone
from rest_framework.exceptions import ValidationError
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .daily import ensure_daily
from .models import Mission, MissionSubmission
from .serializers import MissionSerializer, QuizQuestionSerializer
from .services import verify_mission_photo


def todays_mission(mission_id, **extra):
    """오늘의 미션 중에서만 도전할 수 있어요. 자정이 지나 목록이 바뀐 뒤 어제 미션을 내면 안내해요."""
    try:
        return ensure_daily().get(pk=mission_id, **extra)
    except Mission.DoesNotExist:
        raise ValidationError({'detail': '오늘의 미션이 아니에요. 새로고침해서 새 미션을 확인해 주세요.'})


def grant_reward(user, mission):
    user.points += mission.reward_points
    user.tickets += mission.reward_tickets
    user.save(update_fields=['points', 'tickets'])


class MissionListView(generics.ListAPIView):
    """오늘의 미션 목록. ?category=observation 식으로 필터링. 로그인 안 해도 구경할 수 있어요."""
    serializer_class = MissionSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        qs = ensure_daily()  # 오늘의 미션 (매일 자정에 새로 뽑혀요)
        category = self.request.query_params.get('category')
        if category:
            qs = qs.filter(category=category)
        return qs


class MissionSubmitView(APIView):
    """
    [사진 인증 미션] 사진을 제출하면 AI(Gemini)가 검증하고, 통과해야만 보상이 지급됩니다.
    퀴즈 미션은 이 API가 아니라 /quiz/ 계열 API를 사용합니다.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, mission_id):
        mission = todays_mission(mission_id)
        if mission.mission_type != 'photo':
            return Response({'detail': '이 미션은 사진 인증 미션이 아니에요.'}, status=status.HTTP_400_BAD_REQUEST)

        submission, created = MissionSubmission.objects.get_or_create(
            user=request.user, mission=mission, date=timezone.localdate(),
        )
        if submission.approved:
            return Response({'detail': '이미 완료한 미션이에요.'}, status=status.HTTP_400_BAD_REQUEST)

        if 'photo' in request.data:
            submission.photo = request.data['photo']
            submission.save()

        ai_message = ''
        approved = True
        if mission.ai_assisted and submission.photo:
            try:
                approved, label, ai_message = verify_mission_photo(submission.photo, mission)
                submission.ai_label = label
            except Exception:  # API 오류가 나도 학생 경험이 끊기지 않도록 통과 처리
                approved, ai_message = True, ''

        if not approved:
            submission.save()
            return Response(
                {'detail': f'다시 찍어볼까요? {ai_message}'.strip()},
                status=status.HTTP_400_BAD_REQUEST,
            )

        submission.approved = True
        submission.save()
        grant_reward(request.user, mission)

        label_part = f' (AI: {submission.ai_label})' if submission.ai_label else ''
        return Response({
            'detail': f'미션 완료!{label_part} +{mission.reward_points}P, 티켓 +{mission.reward_tickets}',
            'points': request.user.points,
            'tickets': request.user.tickets,
        })


def needed_to_pass(total):
    """전체 문제의 60% 이상 맞혀야 통과 (3문제면 2개)."""
    return max(1, math.ceil(total * 0.6))


class QuizDetailView(APIView):
    """퀴즈 문제 목록. 정답과 해설은 포함하지 않아요."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, mission_id):
        mission = todays_mission(mission_id, mission_type='quiz')
        questions = list(mission.questions.all())
        if not questions:
            return Response({'detail': '아직 준비 중인 퀴즈예요.'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({
            'id': mission.id,
            'title': mission.title,
            'need': needed_to_pass(len(questions)),
            'questions': QuizQuestionSerializer(questions, many=True).data,
        })


class QuizSubmitView(APIView):
    """
    퀴즈 채점. 요청: {"answers": {"<문제id>": <고른 보기 번호(0부터)>, ...}}
    채점은 서버에서만 하고, 통과했을 때만 정답/해설을 알려주며 보상을 지급해요.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, mission_id):
        mission = todays_mission(mission_id, mission_type='quiz')
        questions = list(mission.questions.all())
        if not questions:
            return Response({'detail': '아직 준비 중인 퀴즈예요.'}, status=status.HTTP_400_BAD_REQUEST)

        answers = request.data.get('answers')
        if not isinstance(answers, dict):
            return Response({'detail': '답안 형식이 올바르지 않아요.'}, status=status.HTTP_400_BAD_REQUEST)

        submission, _ = MissionSubmission.objects.get_or_create(user=request.user, mission=mission, date=timezone.localdate())
        if submission.approved:
            return Response({'detail': '이미 완료한 미션이에요.'}, status=status.HTTP_400_BAD_REQUEST)

        results, correct = [], 0
        for q in questions:
            chosen = answers.get(str(q.id))
            ok = isinstance(chosen, int) and not isinstance(chosen, bool) and chosen == q.answer - 1
            correct += ok
            results.append({'id': q.id, 'correct': ok, '_q': q})

        total, need = len(questions), needed_to_pass(len(questions))
        passed = correct >= need

        if passed:
            submission.approved = True
            submission.save()
            grant_reward(request.user, mission)
            for r in results:
                q = r.pop('_q')
                r['answer'] = q.answer - 1
                r['explanation'] = q.explanation
            return Response({
                'passed': True, 'correct': correct, 'total': total, 'need': need, 'results': results,
                'detail': f'퀴즈 성공! {correct}/{total} · +{mission.reward_points}P, 티켓 +{mission.reward_tickets}',
                'points': request.user.points, 'tickets': request.user.tickets,
            })

        for r in results:
            r.pop('_q')  # 실패했을 땐 어느 문제가 틀렸는지만 알려주고 정답은 숨김
        return Response({
            'passed': False, 'correct': correct, 'total': total, 'need': need, 'results': results,
            'detail': f'{correct}/{total}개 맞혔어요. {need}개 이상 맞혀야 해요. 틀린 문제를 다시 생각해 봐요!',
        })
