from django.contrib.auth.models import AbstractUser
from django.db import models


# 한국 이산화탄소 배경농도(ppm) - 기상청 국립기상과학원 '2025 지구대기감시보고서' 기준
KOREA_AVG_CO2_PPM = 432.7


# 지역은 시·도까지만 선택하게 해요 (상세 주소는 받지 않아요)
REGION_CHOICES = [(x, x) for x in (
    '서울', '부산', '대구', '인천', '광주', '대전', '울산', '세종', '경기',
    '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주',
)]
SCHOOL_CHOICES = [('elementary', '초등학생'), ('middle', '중학생'), ('high', '고등학생')]


class User(AbstractUser):
    """
    기본 Django User에 서비스 전용 재화(포인트, 게임 티켓, 영양제)를 추가한 커스텀 유저 모델.
    index.html 프로토타입의 S.pt / S.tk / S.nutri 상태를 DB로 옮긴 것.
    """
    points = models.PositiveIntegerField(default=0)
    tickets = models.PositiveIntegerField(default=0)
    nutrients = models.PositiveIntegerField(default=0)
    microbes = models.PositiveIntegerField(default=0)  # 보유한 미생물제 개수
    co2_ppm = models.FloatField(default=KOREA_AVG_CO2_PPM)  # 내 정원이 있는 공기 중 CO2 농도
    garden_updated_at = models.DateTimeField(null=True, blank=True)  # 정원 시뮬레이션을 마지막으로 계산한 시각
    friend_code = models.CharField(max_length=20, unique=True, blank=True, null=True)

    # --- 회원가입 정보 / 마이페이지 ---
    region_sido = models.CharField('시·도', max_length=10, choices=REGION_CHOICES, blank=True)
    region_sigungu = models.CharField('시·군·구', max_length=30, blank=True)
    school_level = models.CharField('학교급', max_length=12, choices=SCHOOL_CHOICES, blank=True)
    privacy_consent_at = models.DateTimeField('개인정보 수집·이용 동의 시각', null=True, blank=True)

    def __str__(self):
        return self.username
