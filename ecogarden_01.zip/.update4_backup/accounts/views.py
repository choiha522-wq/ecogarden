from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import User
from .serializers import ProfileUpdateSerializer, RegisterSerializer, UserSerializer


class RegisterView(generics.CreateAPIView):
    """회원가입. 로그인은 simplejwt의 TokenObtainPairView(/api/auth/login/)를 그대로 사용."""
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]


class MeView(APIView):
    """내 정보 + 현재 보유 포인트/티켓/영양제 조회. 프로토타입 헤더의 칩(chip) 영역에 대응."""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)

    def patch(self, request):
        """마이페이지에서 지역/학교급 수정."""
        ser = ProfileUpdateSerializer(request.user, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(UserSerializer(request.user).data)


class ConsumeTicketView(APIView):
    """미니게임 시작 전 티켓 1장 차감. index.html의 play()에서 S.tk-- 하던 부분."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        if user.tickets < 1:
            return Response({'detail': '티켓이 없어요.'}, status=400)
        user.tickets -= 1
        user.save(update_fields=['tickets'])
        return Response(UserSerializer(user).data)


class AddPointsView(APIView):
    """미니게임 결과 포인트 적립. index.html의 fin()에서 S.pt += r 하던 부분."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        amount = int(request.data.get('points', 0))
        amount = max(0, min(amount, 100))  # 비정상적으로 큰 값 방지
        user = request.user
        user.points += amount
        user.save(update_fields=['points'])
        return Response(UserSerializer(user).data)
