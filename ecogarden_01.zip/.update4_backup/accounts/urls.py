from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from .views import AddPointsView, ConsumeTicketView, RegisterView, MeView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', TokenObtainPairView.as_view(), name='login'),
    path('login/refresh/', TokenRefreshView.as_view(), name='login-refresh'),
    path('me/', MeView.as_view(), name='me'),
    path('consume-ticket/', ConsumeTicketView.as_view(), name='consume-ticket'),
    path('add-points/', AddPointsView.as_view(), name='add-points'),
]
